# Hizami Launcher

Launcher Android ringan: jam, bateri, waktu solat (dikira offline), storage/memori, 5 apl kegemaran, cari apl, dock.
Tiada iklan, tiada tracker, tiada dependency luar, tiada kebenaran (permission) berbahaya.

## Cara dapatkan APK (percuma, ~5 minit, tak perlu PC khas)

1. Buat akaun di github.com, tekan **New repository** (Private pun boleh), nama: `hizami-launcher`.
2. Upload SEMUA fail & folder dalam folder ini (termasuk folder `.github`) ke repository itu.
3. Buka tab **Actions** → pilih **Build APK** → **Run workflow**.
4. Tunggu ~3–5 minit sampai hijau ✅, buka run itu, di bahagian **Artifacts** muat turun `HizamiLauncher-apk`.
5. Unzip, hantar `app-release.apk` ke telefon, install (benarkan "Install unknown apps").
6. Tekan butang Home → pilih **Hizami Launcher** → **Always**.

Nak kembali ke launcher lama: Settings → Apps → Default apps → Home app.

## Ubah suai

Semua di atas fail `app/src/main/java/com/hizami/launcher/MainActivity.java` (bahagian TETAPAN PERIBADI):
nama, inisial, zon, koordinat waktu solat, dan senarai 5 apl kegemaran (package name).

- Tekan **search apps...** → taip nama → Enter untuk buka apl pertama.
- Tekan lama pada apl dalam senarai carian → buka maklumat apl (boleh uninstall / disable).
