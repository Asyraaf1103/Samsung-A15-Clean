package com.hizami.launcher;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.RelativeSizeSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    // ====== TETAPAN PERIBADI (ubah di sini) ======
    static final String NAME = "Hizami";
    static final String INITIALS = "hr";
    static final String ZONE = "SGR01";
    static final double LAT = 3.14;    // Selangor (Gombak/Petaling/Sepang...)
    static final double LON = 101.60;
    static final String[] FAV_PKGS = {
            "com.android.chrome", "com.google.android.youtube", "com.google.android.gm",
            "com.google.android.apps.maps", "com.google.android.apps.photos"};
    static final String WHATSAPP = "com.whatsapp";
    // =============================================

    static final int BG = 0xFF1B30C8;
    static final int CARD = 0xFF2A47E0;
    static final int DARK = 0xFF14229A;
    static final int LIME = 0xFFC9F500;
    static final int WHITE = 0xFFFFFFFF;
    static final int INK = 0xFF0A1050;
    static final int DIM = 0xB3FFFFFF;
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    static final String[] PRAYERS = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private float density;
    private int tickCount = 0;

    private TextView tvGreeting, tvDate, tvBattPct, tvBattState, tvNextName, tvIn, tvStorage, tvMemory;
    private final TextView[] prayerNameTv = new TextView[5];
    private final TextView[] prayerTimeTv = new TextView[5];
    private ClockView clock;
    private BarView bar;
    private FrameLayout root;
    private LinearLayout searchPanel;
    private EditText searchBox;
    private AppAdapter adapter;

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        tickCount = 0;
        tick.run();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (Intent.ACTION_MAIN.equals(intent.getAction())) {
            closeSearch();
        }
    }

    @Override
    public void onBackPressed() {
        if (searchPanel.getVisibility() == View.VISIBLE) {
            closeSearch();
        }
        // Di skrin utama, butang back tak buat apa-apa.
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            clock.invalidate();
            if (tickCount % 30 == 0) {
                refreshAll();
            }
            tickCount++;
            handler.postDelayed(this, 1000);
        }
    };

    // ---------------------------------------------------------------- UI helpers

    private int dp(float v) {
        return Math.round(v * density);
    }

    private GradientDrawable box(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private TextView tv(String s, float sp, int color, boolean bold, boolean mono) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(mono ? Typeface.MONOSPACE : Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setIncludeFontPadding(false);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, float weight, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(l, t, r, b);
        return p;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    // ---------------------------------------------------------------- build UI

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        LinearLayout col = vertical();
        col.setPadding(dp(16), dp(14), dp(16), dp(10));

        // --- header
        LinearLayout head = horizontal();
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = vertical();
        tvGreeting = tv("", 22, WHITE, true, false);
        tvDate = tv("", 12, 0xCCFFFFFF, false, true);
        titles.addView(tvGreeting);
        titles.addView(tvDate, lp(WRAP, WRAP, 0, 0, dp(4), 0, 0));
        head.addView(titles, lp(0, WRAP, 1, 0, 0, 0, 0));
        TextView avatar = tv(INITIALS, 18, INK, true, false);
        avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(oval(LIME));
        head.addView(avatar, lp(dp(46), dp(46), 0, 0, 0, 0, 0));
        col.addView(head, lp(MATCH, WRAP, 0, dp(4), 0, dp(4), dp(14)));

        // --- clock + battery
        LinearLayout row2 = horizontal();
        FrameLayout clockCard = new FrameLayout(this);
        clockCard.setBackground(box(CARD, 26));
        clockCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        clock = new ClockView(this);
        clockCard.addView(clock, new FrameLayout.LayoutParams(MATCH, MATCH));
        row2.addView(clockCard, lp(0, dp(170), 1f, 0, 0, dp(6), 0));

        LinearLayout battCard = vertical();
        battCard.setBackground(box(CARD, 26));
        battCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        battCard.addView(tv("BATTERY", 11, DIM, false, true));
        tvBattPct = tv("", 46, WHITE, false, false);
        battCard.addView(tvBattPct, lp(WRAP, WRAP, 0, 0, dp(10), 0, 0));
        tvBattState = tv("", 14, WHITE, false, false);
        battCard.addView(tvBattState, lp(WRAP, WRAP, 0, 0, dp(2), 0, 0));
        bar = new BarView(this);
        battCard.addView(bar, lp(MATCH, dp(8), 0, 0, dp(12), 0, 0));
        row2.addView(battCard, lp(0, dp(170), 1.15f, dp(6), 0, 0, 0));
        col.addView(row2, lp(MATCH, WRAP, 0, 0, 0, 0, dp(12)));

        // --- prayer card
        LinearLayout prayer = vertical();
        prayer.setBackground(box(CARD, 26));
        prayer.setPadding(dp(18), dp(16), dp(18), dp(16));
        prayer.addView(tv("NEXT PRAYER · " + ZONE, 11, DIM, false, true));
        LinearLayout nextRow = horizontal();
        nextRow.setGravity(Gravity.CENTER_VERTICAL);
        tvNextName = tv("", 26, WHITE, true, false);
        nextRow.addView(tvNextName, lp(0, WRAP, 1, 0, 0, 0, 0));
        tvIn = tv("", 13, INK, false, true);
        tvIn.setBackground(box(LIME, 20));
        tvIn.setPadding(dp(14), dp(6), dp(14), dp(6));
        nextRow.addView(tvIn, lp(WRAP, WRAP, 0, 0, 0, 0, 0));
        prayer.addView(nextRow, lp(MATCH, WRAP, 0, 0, dp(10), 0, dp(12)));
        LinearLayout times = horizontal();
        for (int i = 0; i < 5; i++) {
            LinearLayout c = vertical();
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            prayerNameTv[i] = tv(PRAYERS[i].toUpperCase(Locale.ROOT), 11, DIM, false, true);
            prayerTimeTv[i] = tv("--:--", 17, WHITE, false, true);
            c.addView(prayerNameTv[i]);
            c.addView(prayerTimeTv[i], lp(WRAP, WRAP, 0, 0, dp(6), 0, 0));
            times.addView(c, lp(0, WRAP, 1, 0, 0, 0, 0));
        }
        prayer.addView(times, lp(MATCH, WRAP, 0, 0, 0, 0, 0));
        col.addView(prayer, lp(MATCH, WRAP, 0, 0, 0, 0, dp(12)));

        // --- storage + memory pills
        LinearLayout pills = horizontal();
        LinearLayout storage = vertical();
        storage.setGravity(Gravity.CENTER_VERTICAL);
        storage.setBackground(box(WHITE, 42));
        storage.setPadding(dp(24), 0, dp(12), 0);
        storage.addView(tv("STORAGE", 11, 0x990A1050, false, true));
        tvStorage = tv("", 18, INK, false, false);
        storage.addView(tvStorage, lp(WRAP, WRAP, 0, 0, dp(4), 0, 0));
        pills.addView(storage, lp(0, dp(84), 1, 0, 0, dp(6), 0));

        LinearLayout memory = vertical();
        memory.setGravity(Gravity.CENTER_VERTICAL);
        memory.setBackground(box(LIME, 42));
        memory.setPadding(dp(24), 0, dp(12), 0);
        memory.addView(tv("MEMORY", 11, 0x990A1050, false, true));
        tvMemory = tv("", 18, INK, false, false);
        memory.addView(tvMemory, lp(WRAP, WRAP, 0, 0, dp(4), 0, 0));
        pills.addView(memory, lp(0, dp(84), 1, dp(6), 0, 0, 0));
        col.addView(pills, lp(MATCH, WRAP, 0, 0, 0, 0, dp(14)));

        // --- favourite apps row
        LinearLayout favRow = horizontal();
        PackageManager pm = getPackageManager();
        for (String pkg : FAV_PKGS) {
            Intent li = pm.getLaunchIntentForPackage(pkg);
            if (li == null) continue;
            try {
                addIcon(favRow, pm.getApplicationIcon(pkg), li, 58, CARD, 32);
            } catch (PackageManager.NameNotFoundException ignored) {
            }
        }
        col.addView(favRow, lp(MATCH, WRAP, 0, 0, 0, 0, dp(12)));

        // --- search bar
        LinearLayout searchBar = horizontal();
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setBackground(box(CARD, 28));
        searchBar.setPadding(dp(22), 0, dp(22), 0);
        searchBar.addView(tv("search apps...", 15, 0xE6FFFFFF, false, true), lp(0, WRAP, 1, 0, 0, 0, 0));
        View dot = new View(this);
        dot.setBackground(oval(LIME));
        searchBar.addView(dot, lp(dp(9), dp(9), 0, 0, 0, 0, 0));
        searchBar.setOnClickListener(v -> openSearch());
        col.addView(searchBar, lp(MATCH, dp(54), 0, 0, 0, 0, 0));

        // --- spacer
        col.addView(new View(this), lp(MATCH, 0, 1, 0, 0, 0, 0));

        // --- dock
        LinearLayout dock = horizontal();
        dock.setGravity(Gravity.CENTER_VERTICAL);
        dock.setBackground(box(CARD, 42));
        dock.setPadding(dp(8), dp(12), dp(8), dp(12));
        Intent dial = new Intent(Intent.ACTION_DIAL);
        Intent sms = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING);
        Intent cam = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
        Drawable dIcon = iconFor(dial);
        if (dIcon != null) addIcon(dock, dIcon, dial, 68, DARK, 38);
        Drawable sIcon = iconFor(sms);
        if (sIcon != null) addIcon(dock, sIcon, sms, 68, DARK, 38);
        Intent wa = pm.getLaunchIntentForPackage(WHATSAPP);
        if (wa != null) {
            try {
                addIcon(dock, pm.getApplicationIcon(WHATSAPP), wa, 68, LIME, 44);
            } catch (PackageManager.NameNotFoundException ignored) {
            }
        }
        Drawable cIcon = iconFor(cam);
        if (cIcon != null) addIcon(dock, cIcon, cam, 68, DARK, 38);
        col.addView(dock, lp(MATCH, WRAP, 0, 0, dp(12), 0, dp(6)));

        root.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        // --- search overlay
        searchPanel = vertical();
        searchPanel.setBackgroundColor(BG);
        searchPanel.setPadding(dp(16), dp(14), dp(16), dp(10));
        searchPanel.setVisibility(View.GONE);
        searchBox = new EditText(this);
        searchBox.setHint("search apps...");
        searchBox.setHintTextColor(0x99FFFFFF);
        searchBox.setTextColor(WHITE);
        searchBox.setTypeface(Typeface.MONOSPACE);
        searchBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        searchBox.setSingleLine(true);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        searchBox.setBackground(box(CARD, 28));
        searchBox.setPadding(dp(22), dp(14), dp(22), dp(14));
        searchPanel.addView(searchBox, lp(MATCH, WRAP, 0, 0, 0, 0, dp(10)));
        ListView list = new ListView(this);
        list.setDivider(null);
        adapter = new AppAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> launchApp(adapter.getItem(pos)));
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + adapter.getItem(pos).pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            closeSearch();
            startActivity(i);
            return true;
        });
        searchPanel.addView(list, lp(MATCH, 0, 1, 0, 0, 0, 0));
        root.addView(searchPanel, new FrameLayout.LayoutParams(MATCH, MATCH));

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                adapter.filter(s.toString());
            }
        });
        searchBox.setOnEditorActionListener((v, actionId, event) -> {
            if (adapter.getCount() > 0) launchApp(adapter.getItem(0));
            return true;
        });
    }

    private void addIcon(LinearLayout row, Drawable icon, Intent intent, int circleDp, int fill, int iconDp) {
        FrameLayout cell = new FrameLayout(this);
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(icon);
        iv.setBackground(oval(fill));
        int pad = dp((circleDp - iconDp) / 2f);
        iv.setPadding(pad, pad, pad, pad);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        cell.addView(iv, new FrameLayout.LayoutParams(dp(circleDp), dp(circleDp), Gravity.CENTER));
        cell.setOnClickListener(v -> launch(intent));
        row.addView(cell, new LinearLayout.LayoutParams(0, WRAP, 1));
    }

    private Drawable iconFor(Intent intent) {
        PackageManager pm = getPackageManager();
        List<ResolveInfo> list = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        if (list.isEmpty()) return null;
        return list.get(0).loadIcon(pm);
    }

    private void launch(Intent i) {
        try {
            Intent copy = new Intent(i);
            copy.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(copy);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, "Tak dapat buka apl", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------- data refresh

    private void refreshAll() {
        updateGreeting();
        updateBattery();
        updateStorageMemory();
        updatePrayer();
    }

    private void updateGreeting() {
        Calendar now = Calendar.getInstance();
        int h = now.get(Calendar.HOUR_OF_DAY);
        String g = (h >= 5 && h < 12) ? "Good morning" : (h >= 12 && h < 18) ? "Good afternoon" : "Good evening";
        tvGreeting.setText(g + ", " + NAME);
        tvDate.setText(new SimpleDateFormat("EEEE, d MMM yyyy", Locale.ENGLISH).format(now.getTime()));
    }

    private void updateBattery() {
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b == null) return;
        int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        int pct = scale > 0 ? Math.round(level * 100f / scale) : 0;
        boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL;
        SpannableString s = new SpannableString(pct + "%");
        s.setSpan(new RelativeSizeSpan(0.55f), s.length() - 1, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvBattPct.setText(s);
        tvBattState.setText(charging ? "charging" : "on battery");
        bar.setPct(pct);
    }

    private void updateStorageMemory() {
        StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
        tvStorage.setText(gb(fs.getAvailableBytes()));
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        tvMemory.setText(gb(mi.availMem));
    }

    private String gb(long bytes) {
        double g = bytes / 1073741824.0;
        return (g >= 10 ? String.format(Locale.US, "%.0f", g) : String.format(Locale.US, "%.1f", g)) + " GB free";
    }

    private void updatePrayer() {
        Calendar now = Calendar.getInstance();
        double[] t = PrayerTimes.compute(now, LAT, LON);
        double cur = now.get(Calendar.HOUR_OF_DAY) + now.get(Calendar.MINUTE) / 60.0
                + now.get(Calendar.SECOND) / 3600.0;
        int next = -1;
        for (int i = 0; i < 5; i++) {
            if (t[i] > cur) {
                next = i;
                break;
            }
        }
        double nextT;
        if (next == -1) {
            Calendar tm = (Calendar) now.clone();
            tm.add(Calendar.DAY_OF_MONTH, 1);
            nextT = PrayerTimes.compute(tm, LAT, LON)[0] + 24;
            next = 0;
        } else {
            nextT = t[next];
        }
        int mins = (int) Math.ceil((nextT - cur) * 60);
        int hh = mins / 60;
        int mm = mins % 60;
        tvNextName.setText(PRAYERS[next] + " " + fmt(nextT, true));
        tvIn.setText(hh > 0 ? "in " + hh + "h " + mm + "m" : "in " + mm + "m");
        for (int i = 0; i < 5; i++) {
            prayerTimeTv[i].setText(fmt(t[i], false));
            int c = (i == next) ? LIME : WHITE;
            prayerTimeTv[i].setTextColor(c);
            prayerNameTv[i].setTextColor(i == next ? LIME : DIM);
        }
    }

    private String fmt(double hours, boolean ampm) {
        int h = (int) Math.floor(hours);
        int m = (int) Math.round((hours - h) * 60);
        if (m == 60) {
            h++;
            m = 0;
        }
        h = h % 24;
        int h12 = (h % 12 == 0) ? 12 : h % 12;
        String s = h12 + ":" + String.format(Locale.US, "%02d", m);
        return ampm ? s + (h < 12 ? " AM" : " PM") : s;
    }

    // ---------------------------------------------------------------- app search

    private static class AppItem {
        String label;
        String pkg;
        Drawable icon;
        Intent intent;
    }

    private void openSearch() {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<AppItem> items = new ArrayList<>();
        for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
            if (ri.activityInfo.packageName.equals(getPackageName())) continue;
            AppItem a = new AppItem();
            a.label = ri.loadLabel(pm).toString();
            a.pkg = ri.activityInfo.packageName;
            a.icon = ri.loadIcon(pm);
            a.intent = new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setClassName(a.pkg, ri.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            items.add(a);
        }
        Collections.sort(items, new Comparator<AppItem>() {
            @Override
            public int compare(AppItem x, AppItem y) {
                return x.label.compareToIgnoreCase(y.label);
            }
        });
        adapter.setAll(items);
        searchBox.setText("");
        searchPanel.setVisibility(View.VISIBLE);
        searchBox.requestFocus();
        searchBox.post(() -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(searchBox, 0);
        });
    }

    private void closeSearch() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
        searchPanel.setVisibility(View.GONE);
    }

    private void launchApp(AppItem a) {
        closeSearch();
        launch(a.intent);
    }

    private class AppAdapter extends BaseAdapter {
        private List<AppItem> all = new ArrayList<>();
        private List<AppItem> shown = new ArrayList<>();

        void setAll(List<AppItem> items) {
            all = items;
            shown = new ArrayList<>(items);
            notifyDataSetChanged();
        }

        void filter(String q) {
            String s = q.trim().toLowerCase(Locale.ROOT);
            shown = new ArrayList<>();
            for (AppItem a : all) {
                if (s.isEmpty() || a.label.toLowerCase(Locale.ROOT).contains(s)) shown.add(a);
            }
            notifyDataSetChanged();
        }

        @Override public int getCount() { return shown.size(); }
        @Override public AppItem getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            LinearLayout row;
            if (convert == null) {
                row = horizontal();
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(8), dp(8), dp(8), dp(8));
                ImageView iv = new ImageView(MainActivity.this);
                row.addView(iv, new LinearLayout.LayoutParams(dp(42), dp(42)));
                row.addView(tv("", 16, WHITE, false, false), lp(WRAP, WRAP, 0, dp(16), 0, 0, 0));
            } else {
                row = (LinearLayout) convert;
            }
            AppItem a = getItem(pos);
            ((ImageView) row.getChildAt(0)).setImageDrawable(a.icon);
            ((TextView) row.getChildAt(1)).setText(a.label);
            return row;
        }
    }

    // ---------------------------------------------------------------- custom views

    static class ClockView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;

        ClockView(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            p.setStrokeCap(Paint.Cap.ROUND);
        }

        private void line(Canvas c, float cx, float cy, float deg, float from, float to) {
            double a = Math.toRadians(deg);
            float sx = (float) Math.sin(a), sy = (float) -Math.cos(a);
            c.drawLine(cx + sx * from, cy + sy * from, cx + sx * to, cy + sy * to, p);
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(cx, cy);
            for (int i = 0; i < 12; i++) {
                boolean major = i % 3 == 0;
                p.setColor(i == 0 ? LIME : WHITE);
                p.setStrokeWidth((major ? 3f : 2f) * d);
                line(c, cx, cy, i * 30f, r * (major ? 0.78f : 0.86f), r * 0.98f);
            }
            Calendar t = Calendar.getInstance();
            int h = t.get(Calendar.HOUR);
            int m = t.get(Calendar.MINUTE);
            int s = t.get(Calendar.SECOND);
            p.setColor(WHITE);
            p.setStrokeWidth(4f * d);
            line(c, cx, cy, (h + m / 60f) * 30f, 0, r * 0.45f);
            p.setStrokeWidth(3f * d);
            line(c, cx, cy, (m + s / 60f) * 6f, 0, r * 0.68f);
            p.setColor(LIME);
            p.setStrokeWidth(1.6f * d);
            line(c, cx, cy, s * 6f, -r * 0.12f, r * 0.72f);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(cx, cy, 3.5f * d, p);
        }
    }

    static class BarView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int pct = 0;

        BarView(Context c) {
            super(c);
        }

        void setPct(int v) {
            pct = Math.max(0, Math.min(100, v));
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setColor(0x44FFFFFF);
            c.drawRoundRect(new RectF(0, 0, w, h), h / 2, h / 2, p);
            p.setColor(LIME);
            c.drawRoundRect(new RectF(0, 0, Math.max(h, w * pct / 100f), h), h / 2, h / 2, p);
        }
    }
}
