package com.hizami.launcher;

import java.util.Calendar;
import java.util.TimeZone;

/** Waktu solat dikira terus dalam telefon (tanpa internet). Fajr/Isha 18 darjah, Asar mazhab Syafie. */
final class PrayerTimes {
    private PrayerTimes() {}

    static final double FAJR_ANGLE = 18.0;
    static final double ISHA_ANGLE = 18.0;
    static final double SUNSET_ANGLE = 0.833;

    /** Pulangkan {Subuh, Zohor, Asar, Maghrib, Isyak} dalam jam waktu tempatan (cth 5.8 = 5:48). */
    static double[] compute(Calendar date, double lat, double lon) {
        int y = date.get(Calendar.YEAR);
        int m = date.get(Calendar.MONTH) + 1;
        int d = date.get(Calendar.DAY_OF_MONTH);
        double tz = TimeZone.getDefault().getOffset(date.getTimeInMillis()) / 3600000.0;

        double jd = julian(y, m, d) - lon / (15.0 * 24.0);
        double[] sp = sunPosition(jd + 0.5);
        double decl = sp[0];
        double eqt = sp[1];

        double noon = 12.0 + tz - lon / 15.0 - eqt;

        double fajr = angleTime(FAJR_ANGLE, noon, lat, decl, true);
        double dhuhr = noon;
        double asrAngle = -Math.toDegrees(Math.atan(1.0 / (1.0 + Math.tan(Math.toRadians(Math.abs(lat - decl))))));
        double asr = angleTime(asrAngle, noon, lat, decl, false);
        double maghrib = angleTime(SUNSET_ANGLE, noon, lat, decl, false);
        double isha = angleTime(ISHA_ANGLE, noon, lat, decl, false);
        // Ihtiyati (minit tambahan) supaya sepadan dengan jadual JAKIM
        return new double[] {
                fajr + 2 / 60.0, dhuhr + 3 / 60.0, asr + 1 / 60.0, maghrib + 1 / 60.0, isha + 1 / 60.0};
    }

    private static double angleTime(double angle, double noon, double lat, double decl, boolean before) {
        double x = (-Math.sin(Math.toRadians(angle)) - Math.sin(Math.toRadians(lat)) * Math.sin(Math.toRadians(decl)))
                / (Math.cos(Math.toRadians(lat)) * Math.cos(Math.toRadians(decl)));
        x = Math.max(-1.0, Math.min(1.0, x));
        double t = Math.toDegrees(Math.acos(x)) / 15.0;
        return before ? noon - t : noon + t;
    }

    private static double julian(int y, int m, int d) {
        if (m <= 2) {
            y -= 1;
            m += 12;
        }
        double a = Math.floor(y / 100.0);
        double b = 2 - a + Math.floor(a / 4.0);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
    }

    /** {deklinasi matahari (darjah), persamaan masa (jam)} */
    private static double[] sunPosition(double jd) {
        double dd = jd - 2451545.0;
        double g = fixAngle(357.529 + 0.98560028 * dd);
        double q = fixAngle(280.459 + 0.98564736 * dd);
        double l = fixAngle(q + 1.915 * Math.sin(Math.toRadians(g)) + 0.020 * Math.sin(Math.toRadians(2 * g)));
        double e = 23.439 - 0.00000036 * dd;
        double ra = Math.toDegrees(Math.atan2(Math.cos(Math.toRadians(e)) * Math.sin(Math.toRadians(l)),
                Math.cos(Math.toRadians(l)))) / 15.0;
        ra = fixHour(ra);
        double eqt = q / 15.0 - ra;
        if (eqt > 12) eqt -= 24;
        if (eqt < -12) eqt += 24;
        double decl = Math.toDegrees(Math.asin(Math.sin(Math.toRadians(e)) * Math.sin(Math.toRadians(l))));
        return new double[] {decl, eqt};
    }

    private static double fixAngle(double a) {
        a = a - 360.0 * Math.floor(a / 360.0);
        return a < 0 ? a + 360.0 : a;
    }

    private static double fixHour(double a) {
        a = a - 24.0 * Math.floor(a / 24.0);
        return a < 0 ? a + 24.0 : a;
    }
}
